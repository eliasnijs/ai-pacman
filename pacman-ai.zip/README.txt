
  Ai-Pacman

  Project for Artificial Intelligence @ University of Ghent

  Authors:    Bavo Verstraeten, Elias Nijs
  Startdate:  2022-10-10

